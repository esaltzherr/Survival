
/**
 * Write a description of class Id here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public enum State
{
    Menu,
    Help,
    End,
    Shop,
    Game,
    Leaderboard,
    Name;
}
