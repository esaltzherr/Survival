
/**
 * Write a description of class Id here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public enum ID
{
    Player(),
    Bullet(),
    Wall(),
    
    BasicEnemy(),
    FastEnemy(),
    WeirdEnemy(),
    SmartEnemy(),
    BossEnemy(),
    BossBullet(),
    HomingBullet(),
    MenuParticle(),
    
    Trail();
}
